/**
 * @file student.h
 * @author Timothy Leung
 * @brief  student.h file given by professor
 *
 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief student type with fields for first name, last name, ID, grades, number of grades 
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**<first name of the student in string */
  char last_name[50]; /**< last name of the student in string*/
  char id[11]; /**< student ID in string (max 10 characers)*/
  double *grades; /**< grades of the student in list of doubles*/
  int num_grades; /**< number of grades the student has in integer*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
