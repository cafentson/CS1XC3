/**
 * @file course.h
 * @author Timothy Leung
 * @brief course.h provided by professor

 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
/**
 * @brief course type stores a course with fields for name, code, list of student, total_students
 * 
 */
typedef struct _course 
{
  char name[100]; /**< name of course in string */
  char code[10]; /**< course code in string  */
  Student *students; /**< list of students in the course */
  int total_students; /**<total numebr of students in the course (integer) */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


