/**
 * @file course.c
 * @author Timothy Leung
 * @brief course code given provided by professor

 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief enrolls a student into a course 
 * 
 * @param course the course which the student should be enrolled in
 * @param student the student who should be enrolled in a particular course
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) //if this is first entry, must intialize array
  {
    course->students = calloc(1, sizeof(Student));
  }
  else //not 1st entry so array already exists
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //allocate space for new student
  }
  course->students[course->total_students - 1] = *student;//add student
}

/**
 * @brief prints out course name, course code, number of students enrolled, and all students
 * 
 * @param course the course to be printed
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]); //print all students
}

/**
 * @brief finds the student with the highest average in a particular course
 * 
 * @param course the course which should be checked
 * @return Student* a pointer to the student with the highest average in the course 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; //edge case test
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]); //current student avg
    if (student_average > max_average) //if current more than prev biggest, then current is the biggest
    {
      max_average = student_average; //set biggest to now be the current
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief given a course and an integer pointer, will return all the students in the course which
 * have passed while also updating the integer pointer to equal the total number of students passing
 * 
 * @param course the course to be checked
 * @param total_passing the amount of students who are passing (will be updated by the end of the function)
 * @return Student* dynamic array of students who are passing the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++; //count how many students passed
  
  passing = calloc(count, sizeof(Student)); //initialize an array with size based on the number of students who passed

  int j = 0;//indexing variable
  for (int i = 0; i < course->total_students; i++) //loop through all students again
  {
    if (average(&course->students[i]) >= 50) 
    {
      passing[j] = course->students[i]; //add anyone who passed into the passing array
      j++; 
    }
  }

  *total_passing = count; //update total_passing

  return passing;
}